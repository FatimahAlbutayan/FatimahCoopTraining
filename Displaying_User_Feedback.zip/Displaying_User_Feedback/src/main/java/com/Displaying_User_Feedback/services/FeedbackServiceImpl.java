package com.Displaying_User_Feedback.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Displaying_User_Feedback.repository.FeedbackRepository;

import com.Displaying_User_Feedback.model.Feedback;

@Service(value = "FeedbackService")
public class FeedbackServiceImpl implements FeedbackService{

	
	private final FeedbackRepository feedbackRepository;
	
	
	@Autowired
	public FeedbackServiceImpl(FeedbackRepository feedbackRepository) {
		this.feedbackRepository = feedbackRepository;
	}

	@Override
	public List<Feedback> getFeedback() {
		return feedbackRepository.findAll();
	}

	@Override
	public Feedback saveFeedback(Feedback theFeedback) {
		return feedbackRepository.save(theFeedback);
	}

}
