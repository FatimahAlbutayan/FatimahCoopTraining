import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.condition.EnabledOnOs;
import org.junit.jupiter.api.condition.OS;


public class ConditionalTests {

	
	@Test
	@EnabledOnOs({OS.WINDOWS})
	public void excuteOnWindows() {
		System.out.println("this method excuted on windows paltform");
	}
	
	@Test
	@EnabledOnOs({OS.LINUX})
	public void excuteOnLinux() {
		System.out.println("this method excuted on linux paltform");
	}

}
