package com.Displaying_User_Feedback.repository;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.Displaying_User_Feedback.model.Feedback;


@Repository(value = "FeedbackRepository")
public class FeedbackRepositoryImpl implements FeedbackRepository{
	
	private static List<Feedback> feedbacks = new ArrayList<Feedback>();
	
	
	//sample data
	static {
		feedbacks.add(new Feedback("feedback1"));
		feedbacks.add(new Feedback("feedback2"));
		feedbacks.add(new Feedback("feedback3"));
	}
	

	@Override
	public List<Feedback> findAll() {
		
		return feedbacks;
	}

	@Override
	public Feedback save(Feedback theFeedback) {
		if(theFeedback.getFeedback()== null) {
			
		}
		feedbacks.add(theFeedback); //the list
		
		return theFeedback;
	}

}
