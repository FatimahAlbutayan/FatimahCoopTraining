package com.Displaying_User_Feedback;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DisplayingUserFeedbackApplicationTests {

	@Test
	void contextLoads() {
	}

}
