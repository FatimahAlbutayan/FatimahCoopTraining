package com.EcommerceWebsiteforSportyShoes.services;

import java.util.List;

import com.EcommerceWebsiteforSportyShoes.model.Product;

import com.EcommerceWebsiteforSportyShoes.model.User;
import com.EcommerceWebsiteforSportyShoes.model.Admin;

public interface MyService {

	public List<User> getUser();
	public User saveUser(User theUser);
	public User  getUser(Integer theId); 
	
	
	public Product saveProduct(Product theProduct);
	public Product  getProduct1(String theCategory);
	public Product  getProduct2(Integer theDate);
	public Admin getAdmin(String theusername);
	
}
