package com.EcommerceWebsiteforSportyShoes.repository;


import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.EcommerceWebsiteforSportyShoes.model.Product;

import com.EcommerceWebsiteforSportyShoes.model.User;

import com.EcommerceWebsiteforSportyShoes.model.Admin;

@Repository(value = "MyRepository")
public class MyRepositoryImpl implements MyRepository{

	private static List<User> users = new ArrayList<User>();
	private static Integer userCount = 3;
	
	//sample data
	static {
		users.add(new User(101, "Ayui", "ayui","example@gmail"));
		users.add(new User(102, "Byui", "byui","example@hotmail"));
		users.add(new User(103, "Cyui", "cyui","example2@gmail"));
	}
	
	private static List<Product> products = new ArrayList<Product>();
	private static Integer productCount = 3;
	
	//sample data
	static {
		products.add(new Product(2019, "adidas", "y",250));
		products.add(new Product(2020, "NIKE", "x",300));
		products.add(new Product(2021, "asics", "z",450));
	}
	
	private static List<Admin> admin = new ArrayList<Admin>();
	
	
	//sample data
	static {
		admin.add(new Admin("23username", "adidas"));
		
	}
	@Override
	public List<User> findAll() {
		
		return users;
	}

	@Override
	public User findById(Integer theid) {
		for(User theUser : users) {
			if(theUser.getId()== theid) {
				return theUser;
			}
		}
		return null;
	}

	@Override
	public Product findByCategory(String thecategory) {
		for(Product theProduct : products) {
			if(theProduct.getCategory()==thecategory) {
				return theProduct;
			}
		}
		return null;
	}

	@Override
	public Product findByDate(Integer thedate) {
		for(Product theProduct : products) {
			if(theProduct.getDate()==thedate) {
				return theProduct;
			}
		}
		return null;
	}

	@Override
	public Admin findByUsername(String theusername) {
		for(Admin theadmin : admin) {
			if(theadmin.getUsername()==theusername) {
				return theadmin;
			}
		}
		return null;
	}
	@Override
	public User save(User theUser) {
		if(theUser.getId()== null) {
			theUser.setId(++userCount);
		}
		users.add(theUser); //the list
		
		return theUser;
	}

	@Override
	public Product save(Product theProduct) {
		if(theProduct.getName()== null) {
			theProduct.setName(theProduct.getName().toString());
		}
		products.add(theProduct); //the list
		
		return theProduct;
		
	}

	
}
