package com.thirdproject.web;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.thirdproject.dao.newproduct_dao;
import com.thirdproject.model.newproduct;


@WebServlet("/newproductController")
public class newproductController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	 private newproduct_dao dao;

	    public void init() {
	    	dao = new newproduct_dao();
	    }
       
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		add(request, response);
	}
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.sendRedirect("add.jsp");
	}
	
	private void add(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
        String name = request.getParameter("name");
        String description = request.getParameter("description");
       
        
        newproduct product = new newproduct();
        product.setName(name);
        product.setDescription(description);

        dao.saveProduct(product);

        RequestDispatcher dispatcher = request.getRequestDispatcher("add-success.jsp");
        dispatcher.forward(request, response);
    }

	
	

}
