package com.EcommerceWebsiteforSportyShoes.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.EcommerceWebsiteforSportyShoes.model.Admin;
import com.EcommerceWebsiteforSportyShoes.model.Product;
import com.EcommerceWebsiteforSportyShoes.model.User;
import com.EcommerceWebsiteforSportyShoes.repository.MyRepository;

@Service(value = "MyService")
public class MyServiceImpl implements MyService{

	
	private final MyRepository myRepository;

	@Autowired
	public MyServiceImpl(MyRepository myRepository) {
		this.myRepository = myRepository;
	}

	@Override
	public List<User> getUser() {
		return myRepository.findAll();
	}

	@Override
	public User saveUser(User theUser) {
		return myRepository.save(theUser);
		
	}

	@Override
	public User getUser(Integer theId) {
		return myRepository.findById(theId);
	}

	@Override
	public Product saveProduct(Product theProduct) {
		return myRepository.save(theProduct);
		
	}

	@Override
	public Product getProduct1(String theCategory) {
		return myRepository.findByCategory(theCategory);
	}

	@Override
	public Product getProduct2(Integer theDate) {
		return myRepository.findByDate(theDate);
	}

	@Override
	public Admin getAdmin(String theusername) {
		return myRepository.findByUsername(theusername);
	}

	
	
}
