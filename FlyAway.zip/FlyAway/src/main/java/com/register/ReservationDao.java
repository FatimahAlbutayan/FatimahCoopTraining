package com.register;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class ReservationDao {
	
	public int register(reservation r) throws ClassNotFoundException, SQLException {
		
		int result =0;
		
		Class.forName("com.mysql.jdbc.Driver");
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/coop-db","root","root");
		PreparedStatement pre = con.prepareStatement("INSERT INTO reservations"+"(airlines_id, name, phone, address) VALUES "+"(?, ?, ?, ?);");
		pre.setInt(2,r.getAirlines_id());
		pre.setString(3,r.getName());
		pre.setInt(4,r.getPhone());
		pre.setString(5,r.getAddress());
		
		System.out.println(pre);
		result = pre.executeUpdate();
		
		return result;
	}
}
