package com.fourthproject;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Enumeration;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/passdataservlet")
public class passdataservlet extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		
		String name = request.getParameter("name");
		String price = request.getParameter("price");
		String des = request.getParameter("description");
		String du = request.getParameter("duration");
		out.println(name+"<br>");
		out.println(price+"<br>");
		out.println(des+"<br>");
		out.println(du);
		
		/*Enumeration paramname = request.getParameterNames();
		
		while(paramname.hasMoreElements()) 
		{
			String pname = (String) paramname.nextElement();
			out.println("<br>" +request.getParameter(pname));
		}*/
	}

	
	

}
