package com.Firstproject;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.*;

@WebServlet("/loginservlet")
public class loginservlet extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.setContentType("text/html"); 
		PrintWriter out = response.getWriter();
		
		String user = request.getParameter("u");
		String password = request.getParameter("p");
		
		if(user.equals("admin")&&password.equals("admin")) {
			out.println("<h2>Successful Login</h2>");
		    out.println("<br><br>");
		    out.println("To goto main page <a href=index.html> Click HERE </a>");
		}
		else {
			out.println("<h2> Error ! Login Failed </h2>");
			out.println("<br><br>");
		    out.println("To goto main page <a href=index.html> Click HERE </a>");
		}
	}

	
	
		
	

}
