package com.Displaying_User_Feedback.repository;


import java.util.List;

import com.Displaying_User_Feedback.model.Feedback;

public interface FeedbackRepository {
	
	public List<Feedback> findAll();
	
    public Feedback save(Feedback theFeedback);
 

}
