package com.EcommerceWebsiteforSportyShoes.repository;

import java.util.List;

import com.EcommerceWebsiteforSportyShoes.model.Admin;
import com.EcommerceWebsiteforSportyShoes.model.Product;

import com.EcommerceWebsiteforSportyShoes.model.User;

public interface MyRepository {

	public List<User> findAll();
	public User findById(Integer theId);
	public Product findByCategory(String thecategory);
	public Product findByDate(Integer thedate);
	public Admin findByUsername(String theusername);
    public User save(User theUser);
    public Product save(Product theProduct);
    
}
