package com.EcommerceWebsiteforSportyShoes.resources;

import java.net.URI;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import com.EcommerceWebsiteforSportyShoes.model.Admin;
import com.EcommerceWebsiteforSportyShoes.model.Product;
import com.EcommerceWebsiteforSportyShoes.model.User;
import com.EcommerceWebsiteforSportyShoes.services.MyService;


@RestController
public class MyResource {
	@Autowired
	private MyService myService;
	
	//HTTP Method : GET
	//URI : http://localhost:8080/
	//@RequestMapping(path = "/users", method = RequestMethod.GET)
	@GetMapping(path = "/users")
	public List<User> retrieveAllUsers () {
		return myService.getUser();
		
		
	}
	//HTTP Method : GET
	//URI : http://localhost:8080/
	@GetMapping(path = "/users/{theId}")
	public User retrieveUser (@PathVariable Integer theId) {
		User user = myService.getUser(theId);
		return user;
		
	}
	//HTTP Method : GET
	//URI : http://localhost:8080/
		@GetMapping(path = "/users/{theCategory}")
		public Product retrieveproduct (@PathVariable String theCategory) {
			Product p = myService.getProduct1(theCategory);
			return p;
				
		}
		
		//HTTP Method : GET
		//URI : http://localhost:8080/
			@GetMapping(path = "/users/{theDate}")
			public Product retrieveproduct (@PathVariable Integer theDate) {
				Product p = myService.getProduct2(theDate);
				return p;
					
			}
	
	//HTTP Method : POST
	//URI : http://localhost:8080/
	@PostMapping(path = "/users")
	public ResponseEntity createUser(@RequestBody User theUser) {
			User loadedUser = myService.saveUser(theUser);
			// dynamic location
			URI location = ServletUriComponentsBuilder
							.fromCurrentRequest()
							.path("/{theId}")
							.buildAndExpand(loadedUser.getId())
							.toUri();
			return ResponseEntity.created(location).build();
	}
	
	//HTTP Method : PUT    
	//URI : http://localhost:8080/
	@PutMapping(path = "/admin/{theId}")
	@ResponseStatus(HttpStatus.NO_CONTENT)
	public void updateAdmin(@PathVariable String theusername, @RequestBody Admin theAdmin) {
		Admin loadedAdmin = myService.getAdmin(theusername);
		loadedAdmin.setPassword(theAdmin.getPassword());
	}
}
