package com.secondproject.web.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import com.secondproject.web.model.Product;

public class ProductDao {
	
	

	public Product getProduct(int id) {
		Product p = new Product();
		
		try
		{
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/coop-db","root","root");
			Statement st = con.createStatement();
			ResultSet rs = st.executeQuery("select * from product where id=" + id);
			if(rs.next())
			{
				p.setId(rs.getInt("id"));
				p.setName(rs.getString("name"));
				p.setPrice(rs.getInt("price"));
				
			}
			
		}
		catch(Exception e) {
			System.out.println(e);
		}
		return p;
	}
}
