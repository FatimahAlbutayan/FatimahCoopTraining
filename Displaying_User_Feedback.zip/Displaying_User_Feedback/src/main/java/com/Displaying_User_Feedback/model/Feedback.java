package com.Displaying_User_Feedback.model;

public class Feedback {

	private String feedback;

	public Feedback() {
		
	}

	public Feedback(String feedback) {
		super();
		this.feedback = feedback;
	}

	public String getFeedback() {
		return feedback;
	}

	public void setFeedback(String feedback) {
		this.feedback = feedback;
	}

	@Override
	public String toString() {
		return String.format("User [feedback=%s]", feedback);
	}

	
}
