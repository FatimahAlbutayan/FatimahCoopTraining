package com.login.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import org.apache.tomcat.dbcp.dbcp2.DriverManagerConnectionFactory;

public class LoginDao {

	public boolean check(String uname, String pass) throws Exception {
		
		Class.forName("com.mysql.jdbc.Driver");
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/coop-db","root","root");
		PreparedStatement st =con.prepareStatement("select * from admin where username=? and password=?");
		st.setString(1, uname);
		st.setString(2, pass);
		ResultSet rs = st.executeQuery();
		if(rs.next())
		{
			return true;	
		}
		
		
		return false;
	}
}
