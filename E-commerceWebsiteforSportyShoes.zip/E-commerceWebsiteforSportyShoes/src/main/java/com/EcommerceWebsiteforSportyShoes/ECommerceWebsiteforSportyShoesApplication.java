package com.EcommerceWebsiteforSportyShoes;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ECommerceWebsiteforSportyShoesApplication {

	public static void main(String[] args) {
		SpringApplication.run(ECommerceWebsiteforSportyShoesApplication.class, args);
	}

}
