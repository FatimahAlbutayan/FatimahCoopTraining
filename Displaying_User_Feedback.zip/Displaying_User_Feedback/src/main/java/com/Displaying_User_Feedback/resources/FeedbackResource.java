package com.Displaying_User_Feedback.resources;

import java.net.URI;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import com.Displaying_User_Feedback.model.Feedback;
import com.Displaying_User_Feedback.services.FeedbackService;




@RestController
public class FeedbackResource {
	
	@Autowired
	private FeedbackService feedbackService;
	
	//HTTP Method : POST
		//URI : http://localhost:8080/
		@PostMapping(path = "/feedbackss")
		public ResponseEntity createFeedback(@RequestBody Feedback theFeedback) {
			Feedback loadedUser = feedbackService.saveFeedback(theFeedback);
				// dynamic location
				URI location = ServletUriComponentsBuilder
								.fromCurrentRequest()
								.path("/{theFeedback}")
								.buildAndExpand(loadedUser.getFeedback())
								.toUri();
				return ResponseEntity.created(location).build();
		}

}
