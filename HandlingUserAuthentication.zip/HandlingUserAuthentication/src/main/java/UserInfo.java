
public class UserInfo {
 public  String username;
 public  String password;
 
 
 

public UserInfo() {
	
	
}
public  String getUsername() {
	return username;
}
public static String setUsername(String username) {
	return username;
}
public  String getPassword() {
	return password;
}
public static String setPassword(String password) {
	return password;
}
 
 
}
