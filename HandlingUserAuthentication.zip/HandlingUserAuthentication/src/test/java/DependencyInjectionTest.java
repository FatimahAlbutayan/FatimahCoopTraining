import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInfo;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.DisplayName;

public class DependencyInjectionTest {

	@Test
	@DisplayName("TEST 1")
	@Tag("my-tag")
	void test(TestInfo testInfo) {
		assertEquals("TEST 1",testInfo.getDisplayName());
		assertTrue(testInfo.getTags().contains("my-tag"));
	}
}
