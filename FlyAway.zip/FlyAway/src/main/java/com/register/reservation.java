package com.register;

public class reservation {
	int  Airlines_id ;
	String name;
	int phone;
	String address;
	public int getAirlines_id() {
		return Airlines_id;
	}
	public void setAirlines_id(int airlines_id) {
		Airlines_id = airlines_id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getPhone() {
		return phone;
	}
	public void setPhone(int phone) {
		this.phone = phone;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	
	
}
