import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;

@DisplayName("outer class")
public class NestedTestCases {

	@Test
	void test() {
		System.out.println("outer class test method");
	}
	
	@Nested
	@DisplayName("inner class")
	class InnerClass{
		@Test
		void test() {
		System.out.println("inner class test method");
		}
	}
}
