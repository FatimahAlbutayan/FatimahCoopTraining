package com.secondproject.web;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.secondproject.web.dao.ProductDao;
import com.secondproject.web.model.Product;

/**
 * Servlet implementation class GetProductController1
 */
public class GetProductController1 extends HttpServlet {
	
  
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		int pid = Integer.parseInt(request.getParameter("id"));
		ProductDao dao = new ProductDao();
		Product p1 = dao.getProduct(pid);
		
		request.setAttribute("product",  p1);
		
		RequestDispatcher rd = request.getRequestDispatcher("showProduct.jsp");
		rd.forward(request, response);
	}

	

}
