
import java.io.*;
import java.util.Scanner;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;

public class File_Handling {

	public static void main(String[] args) throws FileNotFoundException {
		Scanner scanner = new Scanner(System.in);
		
		System.out.println("Do you whant to read, write, or append to a file?");
		String p = scanner.next();
		FileReader ins = null;
		FileWriter outs = null; 
		switch(p) {
		
		case "read":
			
			System.out.println("Please enter the name of file that you want to read from (example in.txt)");
			String in = scanner.next();
			File inf = new File(in);
			  ins = null; 
			 ins = new FileReader(inf);
			 System.out.println(ins);
			break;
			
		case "writ":
			
			System.out.println("Please enter the name of file that you want to write to (example in.txt)");
			String out = scanner.next();
			 File outf = new File(out);
			  outs = null;  
			  try {  
			     
			   outs = new FileWriter(outf);  
			   int ch;  
			   while ((ch = ins.read()) != -1) {  
			    outs.write(ch);  
			   }  
			  } catch (IOException e) {  
			   System.out.println(e);  
			   System.exit(-1);  
			  } finally {  
			   try {  
			    ins.close();  
			    outs.close();  
			   } catch (IOException e) {}  
			  }  
			break;
			
		case "append":
			
			System.out.println("Please enter the path of the file that you want to append to (example:\\src\\test.txt)");
			String t =  scanner.next();
			String path = System.getProperty("user.dir") + t;
			 System.out.println("Please enter the text:");
			 String text = scanner.next();
					 try {
				            Files.write(Paths.get(path), text.getBytes(), StandardOpenOption.APPEND);
				        } catch (IOException e) {
				        }		 
					
			break;
		
		}
		  
		   
		  
		 
	}

}
