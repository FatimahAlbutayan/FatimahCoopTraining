package com.EcommerceWebsiteforSportyShoes;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ECommerceWebsiteforSportyShoesApplicationTests {

	@Test
	void contextLoads() {
	}

}
