package com.thirdproject.dao;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.thirdproject.model.newproduct;
import com.thirdproject.uti.HibernateUtil;

public class newproduct_dao {
	
	public void saveProduct(newproduct p) {
        Transaction transaction = null;
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            // start a transaction
            transaction = session.beginTransaction();
            // save the student object
            session.save(p);
            // commit transaction
            transaction.commit();
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            e.printStackTrace();
        }
    }

}
