import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.RepeatedTest;
import org.junit.jupiter.api.RepetitionInfo;


public class RepeatedTests {

	UserInfo  u = new UserInfo();
	@RepeatedTest(5)
	public void userauthentcate(RepetitionInfo repetitionInfo) {
		System.out.println("running authentcate function ---->"+repetitionInfo.getCurrentRepetition());
		assertEquals("username", u.setUsername("username"));	
		assertEquals("password", u.setPassword("password"));}
}

	
