package com.search;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class searchservlet
 */
public class searchservlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public searchservlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		PrintWriter out = response.getWriter();
		String city = request.getParameter("city");
		out.print("<table border='1'><tr><th>ID</th><th>Name</th><th>Date</th><th>Source</th><th>Destination</th><th>Number of persons</th><th>Price</th></tr>");
	try 
	{
		Class.forName("com.mysql.jdbc.Driver");
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/coop-db","root","root");
	
		Statement st = con.createStatement();
		ResultSet rs = st.executeQuery("select * from airlines where source="+city+"");
		while(rs.next())
		{
			out.print("<tr><td>");
			out.print(rs.getInt(1));
			out.print("</td>");
			out.print("<td>");
			out.print(rs.getString(2));
			out.print("</td>");
			out.print("<td>");
			out.print(rs.getDate(3));
			out.print("</td>");
			out.print("<td>");
			out.print(rs.getString(4));
			out.print("</td>");
			out.print("<td>");
			out.print(rs.getString(5));
			out.print("</td>");
			out.print("<td>");
			out.print(rs.getInt(6));
			out.print("</td>");
			out.print("<td>");
			out.print(rs.getInt(7));
			out.print("</td>");
			out.print("</tr>");
		}
	}catch(Exception e) 
	{
		System.out.println(e);
	}
	out.print("</table>");
	
	 
	//href of register page 
	out.println("To goto Register page <a href=register.jsp> Click HERE </a>");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
		
	}

}
