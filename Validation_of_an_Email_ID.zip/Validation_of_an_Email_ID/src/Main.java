

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

		
public class Main {
	
	
	 
		

	public static void main(String[] args) {
		
		try (Scanner scanner = new Scanner(System.in)) {
			int i,n,flag=0;
			 String search ;
 System.out.println("Enter the number of emails:") ;
 n = scanner.nextInt();
 String[] a = new String[n];
 
			 System.out.println("Enter the emails") ;
			 for(i=0;i<n;i++)
			 {
			     a[i] = scanner.next();
			 }
 
 System.out.println("Enter the email to be seached");
 search = scanner.next();
			
			 /*Perform search operation*/
			 for(i=0;i<n;i++)
			 {
				 if(a[i]==search)
			     {
				 boolean result = isValidEmail(search);
				if (result) {
					System.out.println(search + " is valid email address.");
				} else {
					System.out.println(search + " is not a valid email address.");
				}
				flag=1;
			    break;
			     }else if(flag==0){
			    	 System.out.println("email "+search+" not found");
			     }
			 }
		}
	     
	}
	
	public static boolean isValidEmail(String email) {
		String s = "^[_A-Za-z0-9-]+(\\.[_A-Za-z0-9-]+)*@[A-Za-z0-9-]+(\\.[A-Za-z0-9-]+)*(\\.[A-Za-z]{2,})$";
		Pattern emailPattern = Pattern.compile(s);
		Matcher m = emailPattern.matcher(email);
		return m.matches();
	}

}
