package com.Displaying_User_Feedback.services;

import java.util.List;

import com.Displaying_User_Feedback.model.Feedback;



public interface FeedbackService {

	public List<Feedback> getFeedback();
	public Feedback saveFeedback(Feedback theFeedback);
}
