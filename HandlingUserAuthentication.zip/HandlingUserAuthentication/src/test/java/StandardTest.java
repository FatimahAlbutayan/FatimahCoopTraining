import static org.junit.jupiter.api.Assertions.fail;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;


@DisplayName("junit5 standard test")
public class StandardTest {
	
	@BeforeAll
	static void initAll() {
		System.out.println("before all the  test methods");
	}
	
	@BeforeEach
	public void init() {
		System.out.println("before each the  test methods");
	}
	
	@Test
	public void SuccessfulVerification() {
		System.out.println("succeding test");
	}
	
	@Test
	public void FailedVerification() {
		System.out.println("failing test");
		fail("always test fails");
	}
	
	@Test
	@Disabled
	public void skippedTest() {
		
	}
	
	@AfterEach
	public void teardowen() {
		System.out.println("after each test method is invoked");
	}
	
	@AfterAll
	static void tearDowenAll() {
		System.out.println("after all test method is excuted");
	}
}
