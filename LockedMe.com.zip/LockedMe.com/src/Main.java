import java.util.Scanner;
import java.io.File;
import java.io.IOException;

public class Main {

	public static void main(String[] args) {
		
		int flag1 = 0;
		int lu = 0;
		 String[] filelist;
		
		// create an object of Scanner class
	    Scanner input = new Scanner(System.in);
	    File lockedme = new File("E:/");
	    filelist = lockedme.list();
	    //welcome screen	
	    System.out.println("welcome to LockedMe.com application \nWe are happy to serve you! \n\n"
	    		+ "developer details:\nName: Fatimah Albutayan\nPhone #: 0508549156\nEmail:217029826@student.kfu.edu.sa\n");
	    System.out.println("The current files:");
	    for (int i = 0; i < filelist.length; i++)
	    {System.out.println(filelist[i]+"\n");}
	    while(flag1!=1) {
	 // ask users to enter the option
		System.out.println("Enter the number of operations that you want to do: \n1-add file.\n2-delete file.\n3-search for file.\n4-go back.\n5-close the app.");
		int option = input.nextInt();
		switch (option) {

	      // Option to add a user specified file to the application
	      case 1:
	        
	        System.out.println("Enter File name:");
	        String name = input.next();
	        System.out.println("Enter File extension :");
	        String ex = input.next();
	        String path = "E:/"+name+"."+ex;
	        try {
	        	 File file = new File(path);
	            /*If file gets created then the createNewFile() 
	                method would return true or if the file is 
	                already present it would return false */
	            boolean flag = file.createNewFile();
	            if (flag) {
	              System.out.println("File has been created successfully at the specified location");
	              
	            }
	            else {
	              System.out.println("File already present at the specified location");
	            }
	          }
	          catch(IOException e) {
	            System.out.println("Exception Occurred:");
	            e.printStackTrace();
	          }
	       
	        break;

	      // Option to delete a user specified file from the application
	      case 2:
	    	  
	    	  System.out.println("Enter File name:");
		        String name2 = input.next();
		        System.out.println("Enter File extension :");
		        String ex2 = input.next();
		        String path2 = "E:/"+name2+"."+ex2;
	    	  try {
	    	      
	    	  File f = new File(path2);
	    	  
	    	  for (int i = 0; i < filelist.length; i++) {
	                 
                  if (filelist[i].equals(name2+"."+ex2)) {
                      
                	  f.delete();
                	  System.out.println("File " + f.getName() + " is deleted");
                	  lu = 1;
                  }
              } if (lu==0) {
    	          System.out.println("Delete operation failed -File Not Found-");
    	      }
	    	
    	    }
	    	    catch(Exception e) {
	    	      e.printStackTrace();
	    	    }
	        break;

	      // Option to search a user specified file from the application the user needs to specify the exact name of the file
	      case 3:
	       
	    	// Replace the file path with path of the directory
	          File directory = new File("E:/");
	    
	          // store all names with same name
	          // with extension
	          String[] flist = directory.list();
	          int flag2 = 0;
	          if (flist == null) {
	              System.out.println("Empty directory.");
	          }
	          else {
	        	  System.out.println("Enter File name\nspecify the exact name of the file  please (example myfile.txt):");
	        	  String filename = input.next();
	              // Linear search in the array
	              for (int i = 0; i < flist.length; i++) {
	                 
	                  if (flist[i].equals(filename)) {
	                      System.out.println(filename + " found");
	                      flag2 = 1;
	                  }
	              }
	          }
	    
	          if (flag2 == 0) {
	              System.out.println("File Not Found");
	          }
	        break;
	     // Navigation option to close the current execution context and return to the main context
	      case 4:
	    	
	    	  System.out.println("welcome to LockedMe.com application \nWe are happy to serve you! \n\n"
	  	    		+ "developer details:\nName: Fatimah Albutayan\nPhone #: 0508549156\nEmail:217029826@student.kfu.edu.sa\n");
	    	  
	    	  continue;
	     //Option to close the application   
	      case 5:
	    	  System.out.println("Goodbye!");
		       flag1 = 1;
		       break;
		       
	    }// end switch
		
		
		
	    }// end while loop
	   
	    
		
	   
	}

}
